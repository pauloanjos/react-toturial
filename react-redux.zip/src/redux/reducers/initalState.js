export default {
    courses: [],
    authors: []
};
